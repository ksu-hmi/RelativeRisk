	/*
		Author: Marquis Morgan
		Date: 03 December 2021
		Filename: rrrv.js
	*/
	
	function reviews(e) {
		
		var firstName = document.getElementById("fName").value;
		var lastName = document.getElementById("lName").value;
		var email = document.getElementById("mail").value;
		var age = document.getElementById("age").value;
		var male = document.getElementById("gM").value;
		var female = document.getElementById("gF").value;
		var nonBinary = document.getElementById("gNB").value;
		var pNTS = document.getElementById("gPS").value;
		
		validity = true;
		if(firstName.value && lastName.value && email.value && age.value && (male.checked || female.checked || nonBinary.checked || pNTS.checked)) {
			alert("Thank You for your submission!");
		} else {
			alert("Please revert back and complete the missing entries!");
			e.preventDefault();
		}
		testFormCompleteness();
	}
